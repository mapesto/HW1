﻿using UnityEngine;

public class HandScript : MonoBehaviour
{
    Vector3 mousePosition;
    public float moveSpeed = 0.1f;
    Rigidbody2D rb;
    Vector2 position = new Vector2(0f, 0f);


    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

  

     void Update()
    {
      

        mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);
        position = Vector2.Lerp(transform.position, mousePosition, moveSpeed);
        if (Input.GetKeyDown(KeyCode.LeftArrow) == true)
        {
            Vector2 playerVector = new Vector2(transform.position.x - 0.7f, transform.position.y);
            transform.position = playerVector;
        }

        if (Input.GetKeyDown(KeyCode.RightArrow) == true)
        {
            Vector2 playerVector = new Vector2(transform.position.x + 0.7f, transform.position.y);
            transform.position = playerVector;

        }

        if (Input.GetKeyDown(KeyCode.UpArrow) == true)
        {
            Vector2 playerVector = new Vector2(transform.position.x, transform.position.y + 0.7f);
            transform.position = playerVector;

        }

        if (Input.GetKeyDown(KeyCode.DownArrow) == true)
        {
            Vector2 playerVector = new Vector2(transform.position.x , transform.position.y - 0.7f);
            transform.position = playerVector;

        }
        if (Input.multiTouchEnabled)
        {
            mousePosition = Input.mousePosition;
            mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);
            transform.position = Vector2.Lerp(transform.position, mousePosition, moveSpeed);
        }
    }





}

